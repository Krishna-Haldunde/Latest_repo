# Application to store ORO application locales.

## Run Commands

#### `npm build`

## Word Count Application
run `node wordCount` in `src/` folder to run node application on localhost:3000 to check tenant files word count.

## For code conventions and standards
#### https://www.notion.so/orolabs/Translation-Approach-i18next-a70efd9fe53948859ee3630eff5ed2d7